import React from 'react'
import { Switch } from 'react-router-dom'

function UserRouter() {
    return (
        <div>
            
        </div>
    )
}

export default UserRouter
