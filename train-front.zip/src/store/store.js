import { act } from 'react-dom/test-utils';
import { combineReducers, createStore } from 'redux';

const userInitialState = {
    inAuthenticated: false,
    type:'Guest'
}


const trainReducer = (state=[],action) =>{
    switch (action.type) {
        case 'SET_TRAINS':
            return action.trains
            break;
        case 'GET_TRAINS':
            return action.trains
            break;
        default:
            return action
            break;
    }
}
const filterInitialState = {

}
const filterTrainsReducer = (state=[],action)=>{
    switch (action.type) {
        case 'SET_STATION_FILTER':
            const trains = action.trains
            console.log(action)
            let filteredStations = [] 
            if(!action.start_station && !action.end_station) {
                return action.trains
            }
            trains.map((train)=>{
                const route = train.train_id.route
                const startStation = action.start_station ? route.findIndex(route=>route.station_name.toLowerCase()=== action.start_station.toLowerCase()) : null;
                const endStation =  action.end_station ? route.findIndex(route=>route.station_name.toLowerCase() === action.end_station.toLowerCase()) : null;
                if (!action.start_station && action.end_station && endStation > -1 || action.start_station && !action.end_station && startStation>-1) {
                    filteredStations.push(train)
                }
                if(startStation !== -1 && endStation !== -1 && startStation < endStation){
                    console.log(route.findIndex(route => route.station_name.toLowerCase() === action.start_station.toLowerCase()))
                    const start_station = route.findIndex(route => route.station_name.toLowerCase() === action.start_station.toLowerCase())
                    const end_station = route.findIndex(route => route.station_name.toLowerCase() === action.end_station.toLowerCase())
                    console.log(start_station,end_station)
                    console.log(route[start_station].distance)
                    console.log(route[end_station].distance)
                    const distace = route[end_station].distance - route[start_station].distance
                    const time = route[end_station].arriving_time - route[start_station].departure_time
                    filteredStations.push({...train,distace,time})
                }
                
                // const matchingStations = train.train_id.route.filter((route)=>{
                //     console.log(route.station_name.toLowerCase()==action.start_station.toLowerCase())
                //     console.log(route)
                //     return route.station_name.toLowerCase() == action.start_station.toLowerCase()
                // })
                // console.log(filteredStations)
                // filteredStations = filteredStations.concat(matchingStations)  
            })

            return filteredStations
        default:
            return state
    }
}

const store = createStore(
    combineReducers({
        trains: trainReducer,
        filter: filterTrainsReducer
    })
)

export default store